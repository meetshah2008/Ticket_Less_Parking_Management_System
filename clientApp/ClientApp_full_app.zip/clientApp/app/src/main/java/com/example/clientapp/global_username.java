package com.example.clientapp;

public class global_username {

    public static String username = "";

    public static String getUserid() {
        return userid;
    }

    public static void setUserid(String userid) {
        global_username.userid = userid;
    }

    public static  String userid = "";

    public static void setUsername(String name){
        username  = name;
    }

    public  static String getUsername(){
        return username;
    }

}
